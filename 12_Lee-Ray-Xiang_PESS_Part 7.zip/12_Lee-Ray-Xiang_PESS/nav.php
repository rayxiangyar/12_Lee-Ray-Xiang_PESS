<img src="banner.jpg" alt="banner">

<link href="nav.css" rel="stylesheet" type="text/css">


<div class="navbar">
  <a class="active" href="logcall.php"></i> Log Call</a> 
  <a href="Update.php"></i> Update</a> 
  <a href="http://localhost/phpmyadmin/index.php?route=/sql&server=1&db=pessdb&table=dispatch&pos=0"></i> Report</a> 
  <a href="http://localhost/phpmyadmin/index.php?route=/sql&server=1&db=pessdb&table=dispatch&pos=0"></i> History</a>
</div>



