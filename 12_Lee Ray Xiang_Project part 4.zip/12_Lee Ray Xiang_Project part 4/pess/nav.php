<img src="banner.jpg" alt="banner">


<style>
* {box-sizing: border-box}
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #000000;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
  width: 25%; 
  text-align: center;
}

.navbar a:hover {
  background-color: #E8B200;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
    width: 100%;
    text-align: left;
  }
}
	
	
	img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>

<div class="navbar">
  <a class="active" href="logcall.php"></i> Log Call</a> 
  <a href="update.php"></i> Update</a> 
  <a href="report.php"></i> Report</a> 
  <a href="history.php"></i> History</a>
</div>



