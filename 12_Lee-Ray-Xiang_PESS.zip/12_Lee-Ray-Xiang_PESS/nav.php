<img src="banner.jpg" alt="banner">

<link href="nav.css" rel="stylesheet" type="text/css">


<div class="navbar">
  <a class="active" href="logcall.php"></i> Log Call</a> 
  <a href="Update.php"></i> Update</a> 
  <a href="report.php"></i> Report</a> 
  <a href="history.php"></i> History</a>
</div>



